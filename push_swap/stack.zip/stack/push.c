/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 02:01:35 by marvin            #+#    #+#             */
/*   Updated: 2021/11/06 02:04:13 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "stack.h"

void	push(t_stack_item stack_item, t_stack my_stack)
{
	if (is_stack_full(my_stack))
	{
		printf("The stack is full!!!!!!");
		abort();
	}
	my_stack->top++;
	my_stack->item[my_stack->top] = stack_item;
}
