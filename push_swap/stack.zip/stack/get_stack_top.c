/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_stack_top.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 02:01:17 by marvin            #+#    #+#             */
/*   Updated: 2021/11/06 02:10:25 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "stack.h"

t_stack_item	get_stack_top(t_stack my_stack)
{
	if (is_stack_empty(my_stack))
	{
		printf("The stack is empty!");
		abort();
	}
	return (my_stack->item[my_stack->top]);
}
