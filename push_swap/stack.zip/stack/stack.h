/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 02:01:31 by marvin            #+#    #+#             */
/*   Updated: 2021/11/06 02:16:27 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_H
# define STACK_H

# include <stdlib.h>

typedef int	t_stack_item;

typedef struct s_stack
{
	int				max;
	int				index_top;
	t_stack_item	*item;
}	*t_stack;

t_stack				create_stack(int stack_size);
t_stack_item		pop(t_stack my_stack);
void				push(t_stack_item stack_item, t_stack my_stack);
int					is_stack_empty(t_stack my_stack);
int					is_stack_full(t_stack my_stack);
t_stack_item		get_stack_top(t_stack my_stack);
void				destroy_stack(t_stack *my_stack);

#endif