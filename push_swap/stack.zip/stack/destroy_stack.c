/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   destroy_stack.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 02:00:59 by marvin            #+#    #+#             */
/*   Updated: 2021/11/06 02:10:37 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "stack.h"

void	destroy_stack(t_stack *my_stack)
{
	free((*my_stack)->item);
	free(*my_stack);
	*my_stack = NULL;
}
