/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pop.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 02:01:27 by marvin            #+#    #+#             */
/*   Updated: 2021/11/06 02:09:53 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "stack.h"

t_stack_item	pop(t_stack my_stack)
{
	t_stack_item	stack_item;

	if (is_stack_empty(my_stack))
	{
		printf("The stack is empty!")
		abort();
	}
	stack_item = my_stack->item[my_stack->top];
	my_stack->top--;
	return (stack_item);
}
