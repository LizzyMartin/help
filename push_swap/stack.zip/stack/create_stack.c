/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_stack.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 02:01:10 by marvin            #+#    #+#             */
/*   Updated: 2021/11/06 02:12:36 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "stack.h"

t_stack	create_stack(int stack_size)
{
	t_stack	my_stack;

	my_stack = malloc(sizeof(t_stack));
	my_stack->max = stack_size;
	my_stack->top = -1;
	my_stack->item = malloc(stack_size * sizeof(t_stack_item));
	return (my_stack);
}
